package stringformats;


public class StringFormatting
{
	public static void main(String[] args)
	{
		String str1 = "Eve";
		double gpa1 = 4.0;
		int age1 = 8;

		String str2 = "Zelda";
		double gpa2 = 3.8;
		int age2 = 12;

		String str3 = String.format(
			"%1s is %1d years old and has a gpa of %1.2f.",
			str1, age1, gpa1);
		System.out.println(str3);

		String str4 = String.format(
			"%1s is %1d years old and has a gpa of %1.2f.",
			str2, age2, gpa2);
		System.out.println(str4);
		System.out.println();

		String str5 = String.format(
			"Name: %-8s   Age: %2d   GPA: %5.2f",
			str1, age1, gpa1);
		System.out.println(str5);

		String str6 = String.format(
			"Name: %-8s   Age: %2d   GPA: %5.2f",
			str2, age2, gpa2);
		System.out.println(str6);
		System.out.println();
		// OR, instead of creating the formatted string
		// and then printing it, just print it directly
		// using printf
		System.out.printf(
			"%1s is %1d years old and has a gpa of %1.2f.",
			str1, age1, gpa1);
		System.out.println();
		System.out.printf(
			"%1s is %1d years old and has a gpa of %1.2f.",
			str2, age2, gpa2);
		System.out.println();
		System.out.println();
		System.out.printf(
			"Name: %-8s   Age: %2d   GPA: %5.2f",
			str1, age1, gpa1);
		System.out.println();
		System.out.printf(
			"Name: %-8s   Age: %2d   GPA: %5.2f",
			str2, age2, gpa2);
		System.out.println();
	}
}

/** OUTPUT
Eve is 8 years old and has a gpa of 4.00.
Zelda is 12 years old and has a gpa of 3.80.

Name: Eve        Age:  8   GPA:  4.00
Name: Zelda      Age: 12   GPA:  3.80

Eve is 8 years old and has a gpa of 4.00.
Zelda is 12 years old and has a gpa of 3.80.

Name: Eve        Age:  8   GPA:  4.00
Name: Zelda      Age: 12   GPA:  3.80
 */
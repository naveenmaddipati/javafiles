/*
 * @author merry
 * @version Mar 13, 2007
 */

public class Student implements Comparable <Student>
{
	private String idNum;
	private String lastName;
	private String firstName;
	private double gpa;

	public Student(String idNum, String lastName, String firstName, double gpa)
	{
		this.idNum = idNum;
		this.lastName = lastName;
		this.firstName = firstName;
		this.gpa = gpa;
	}
	public String getFirstName()
	{
		return firstName;
	}
	public double getGpa()
	{
		return gpa;
	}
	public String getIdNum()
	{
		return idNum;
	}
	public String getLastName()
	{
		return lastName;
	}
	public int compareTo(Student stu)
	{
		return idNum.compareTo(stu.idNum);
	}
	@Override
	public String toString()
	{
		return idNum + " " + lastName + ", " + firstName + " " + gpa;
	}

}

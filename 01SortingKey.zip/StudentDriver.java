import java.util.*;

public class StudentDriver
{
	public static void main(String[] args)
	{
		ArrayList<Student> studentList = new ArrayList<Student>();
		studentList.add(new Student("333", "Smith", "Joe", 3.50));
		studentList.add(new Student("222", "Brown", "Betty", 3.8));
		studentList.add(new Student("444", "Anders", "Alex", 3.92));
		studentList.add(new Student("111", "Samson", "Susie", 3.93));
		studentList.add(new Student("555", "Smith", "Andy", 2.75));
		studentList.add(new Student("440", "Smith", "Susan", 3.00));
		
		System.out.println("Students in original order:");
		for(Student s : studentList)
		{
			System.out.println(s);
		}
		System.out.println();
		
		// Sort the students into natural order (by id number)
		Collections.sort(studentList);
		System.out.println("Students in alphabetical order by id number:");
		for(Student s : studentList)
		{
			System.out.println(s);
		}
		System.out.println();
		
		// Sort the students into increasing order by gpa
		Collections.sort(studentList, new Comparator<Student>()
      		{
					public int compare(Student s1, Student s2)
					{
						if(s1.getGpa() < s2.getGpa())
							return -1;
						else if (s1.getGpa() == s2.getGpa())
							return 0;
						else
							return +1;
					}
      		});
		System.out.println("Students in increasing order by gpa:");
		for(Student s : studentList)
		{
			System.out.println(s);
		}
		System.out.println();
		
		//	 Sort the students into increasing order by last name, first name
		Collections.sort(studentList, new Comparator<Student>()
      		{
					public int compare(Student s1, Student s2)
					{
						if(s1.getLastName() == s2.getLastName())
						{
							return (s1.getFirstName()).compareTo(s2.getFirstName());
						}else
						{
							return s1.getLastName().compareTo(s2.getLastName());
						}
					}
      		});
		System.out.println("Students in order by last name, first name:");
		for(Student s : studentList)
		{
			System.out.println(s);
		}
		System.out.println();


	}

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptions;

/**
 *
 * @author Sammy
 */
public class IllegalGradeException extends Exception {

    /**
     * Creates a new instance of
     * <code>IllegalGradeException</code> without detail message.
     */
    public IllegalGradeException() {
    }

    /**
     * Constructs an instance of
     * <code>IllegalGradeException</code> with the specified detail message.
     *
     * @param msg the detail message.
     */
    public IllegalGradeException(String msg) {
        super(msg);
    }
}

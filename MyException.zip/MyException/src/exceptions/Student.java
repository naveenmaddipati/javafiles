package exceptions;

import java.util.ArrayList;

public class Student 
{
   private String name;
   private ArrayList<Integer> grades;

   public Student(String name)
   {
      this.name = name;
      this.grades = new ArrayList<Integer> ();
   }
   
   public void addGrade(int grade) throws IllegalGradeException 
   {
      if(grade < 0 || grade > 100)
      {
          throw new IllegalGradeException("The constructor with arg.");
      }
      grades.add(grade);
   }
   
   
   public String toString()
   {
      String str = name;
      for(int grade : grades)
      {
         str += " " + grade;
      }
      return str;
   }
   
}

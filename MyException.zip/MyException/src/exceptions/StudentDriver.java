package exceptions;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Merry McDonald
 */
public class StudentDriver {

    public static void main(String[] args) {
        Scanner in = null;
        try {
            in = new Scanner(new File("grades.txt"));
        } catch (FileNotFoundException ex) {
            System.out.println("The file can not be found." + ex);
        } 
        while (in.hasNext()) {
            String[] studentInfo = in.nextLine().split(" ");
            Student student = new Student(studentInfo[0]);
            for (int i = 1; i < studentInfo.length; i++) {
                try {
                    student.addGrade(Integer.parseInt(studentInfo[i]));
                } catch (IllegalGradeException ex) {
                    System.out.println(ex+"\n Exception a: " + studentInfo[0] + " " + i + " " + studentInfo[i]);
                }
            }
            System.out.println(student);
        }
    }
}
